# Build this firmware in GitHub Actions (no ESP-IDF installation on your PC)

## 1. Create a GitHub repository
1. Sign in at https://github.com and create a new repository, e.g. `xiaozhi-ai-eye-oled`.
2. Keep it private if you prefer. Do not upload Wi-Fi passwords, API tokens, or other secrets in source files.
3. Download/extract this ZIP on your PC. Upload the **contents of the extracted project folder** to the repository root (the root must contain `CMakeLists.txt`, `main/`, `components/`, and `.github/`). The easiest method is GitHub's web UI → Add file → Upload files; drag the extracted files/folders. If the web UI struggles with this large project or doesn't preserve submodules, use GitHub Desktop.
4. Commit to the `main` branch. The included `.github/workflows/build-esp32s3.yml` should start automatically. If it does not, open Actions → “Build Xiaozhi AI Eye (ESP32-S3)” → Run workflow.

## 2. Check the cloud build
1. Open the workflow run and wait for it to finish.
2. Green check = build step succeeded. Red X = open the failed step and read the first real compiler/configuration error. A failed build does not produce a usable firmware image.
3. At the bottom of a successful run, download the artifact named `xiaozhi-ai-eye-esp32s3-firmware` and extract it on your PC.

## 3. Flash with a browser
1. Open https://espressif.github.io/esp-launchpad/ in Chrome or Edge.
2. Choose DIY, connect the ESP32-S3 USB serial port, and select the extracted firmware binaries.
3. Use the exact flash addresses from the build's `build/flasher_args.json` / `build/flash_args` output. Do not guess addresses. If Launchpad requires multiple files and addresses, add each image at its listed address.
4. If you cannot see the required address map or the artifact doesn't contain all needed images, stop and share the build artifact file list and `flasher_args.json` rather than guessing.

## Important
- This workflow attempts a cloud build; it does not guarantee the custom board adaptation compiles. Use the Actions logs to fix any errors.
- The ESP-IDF CI action builds inside Espressif's Docker image, so the ESP-IDF toolchain is downloaded/used by GitHub's runner, not installed on your local drive.
- The source uses the inherited board selection/configuration. Confirm the selected board is the intended Bread Compact WiFi + Camera entry, and validate camera/audio/OLED on hardware after flashing.
- Never publish credentials or private keys in the repository.
