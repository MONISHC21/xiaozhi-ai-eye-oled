# Xiaozhi AI Eye — ESP32-S3 CAM + SSD1306 OLED adaptation

This is a source adaptation of the uploaded `xiaozhi-esp32-2.2.4` project. It preserves the original camera and simplex I2S audio GPIOs and replaces the original SPI TFT initialization with the project's existing ESP-IDF SSD1306/LVGL display driver.

## Wiring used by this adaptation

- INMP441: VDD 3V3, GND GND, WS GPIO1, SCK GPIO2, SD GPIO42, L/R GND.
- MAX98357A: VIN regulated 5V, GND common, DIN GPIO39, BCLK GPIO40, LRC GPIO41; speaker only on SPK+ / SPK-.
- SSD1306 128x64 I2C: VCC 3V3, GND GND, SDA GPIO38, SCL GPIO21. Firmware assumes I2C address 0x3C.
- Camera ribbon stays connected; camera pin map remains the original one in `config.h`.
- BOOT button GPIO0 is used as in original board code.

GPIO38 is normally SD CMD and GPIO21 was the original TFT reset line. They are repurposed here because SD and TFT are not used. Do not use an SD card with this pin assignment. Check the OLED address (0x3C vs 0x3D) if initialization fails.

## Build/flash on Windows

1. Install Espressif ESP-IDF v5.5.x and its VS Code extension using Espressif's official installer. Open the **ESP-IDF Terminal**, not a plain PowerShell window.
2. Extract this project folder to a short path such as `C:\esp\xiaozhi-esp32-2.2.4-oled`.
3. In the ESP-IDF terminal, `cd` to the folder containing the top-level `CMakeLists.txt`.
4. Run:

   ```bat
   idf.py set-target esp32s3
   idf.py menuconfig
   ```

5. In menuconfig choose **Xiaozhi Assistant → Board Type → Bread Compact WiFi + LCD + Camera**. This menu label is inherited from upstream even though the LCD code was changed to SSD1306.
6. Save and exit, then run:

   ```bat
   idf.py fullclean
   idf.py build
   idf.py -p COMx flash monitor
   ```

   Replace `COMx` with the actual ESP32-S3 serial port, e.g. `COM5`.

If flashing fails, close Serial Monitor and try holding BOOT, tapping RESET, releasing RESET, then releasing BOOT; retry `idf.py -p COMx flash`.

## Important limitations / validation

- This is a firmware source patch, not a precompiled `.bin`; compile it with the correct ESP-IDF environment and all repository-managed dependencies.
- The uploaded source bundle contains no prebuilt firmware, and this environment does not have ESP-IDF installed, so I cannot honestly claim the modified project has been compiled or tested on your exact board.
- The repository's camera source expects the camera model/driver compatible with its original configuration. The earlier camera test shows your camera works in your separate test firmware, but that alone does not prove this project's camera driver/model setting is correct.
- If the OLED's I2C address differs, edit `io_config.dev_addr` in `compact_wifi_board_s3cam.cc`.
- Do not change microphone/speaker GPIO definitions unless you also change the actual wiring.
